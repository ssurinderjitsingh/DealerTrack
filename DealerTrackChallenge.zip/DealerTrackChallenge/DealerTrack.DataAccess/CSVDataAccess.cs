﻿using System;
using System.IO;
using System.Collections.Generic;
using DealerTrack.DataContracts;
using System.Linq;
using System.Text.RegularExpressions;

namespace DealerTrack.DataAccess
{
    public class CSVDataAccess
    {
        public List<VehicleSalesData> GetVehicleSalesData()
        {
            Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");

            var fileName = @"C:\Demo\Dealertrack-CSV-Example.csv";
            if (File.Exists(fileName))
            {
                var file = loadCsvFile(fileName);
                foreach(var line in file)
                {
                    var result = Regex.Split(line, ",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                }
                

                return File.ReadLines(fileName)
                    .Skip(1)
                    .Where(s => s != "")
                    .Select(s => s.Split(new[] { ',' }))
                    .Select(a => new VehicleSalesData
                    {
                        DealerNumber = int.Parse(a[0]),
                        CustomerName = a[1],
                        DealershipName = a[2],
                        Vehicle = a[3],
                        //Price = decimal.Parse(a[4], System.Globalization.NumberStyles.Currency),
                        Date = DateTime.Parse(a[6]),
                    })
                    .ToList();
            }
            return null;
        }

        public List<string> loadCsvFile(string filePath)
        {
            var fileName = @"C:\Demo\Dealertrack-CSV-Example.csv";

            var reader = new StreamReader(File.OpenRead(fileName));
            List<string> searchList = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                searchList.Add(line);
            }
            return searchList;
        }
    }
}
