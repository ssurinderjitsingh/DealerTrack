﻿using System;
using DealerTrack.DataContracts;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Description;
using DealerTrack.Parser;
using System.Net.Http;
using System.Net;

namespace DealerTrack.WebApi.Controllers
{
    public class CSVApiController : ApiController
    {
      
        private CSVParser _csvParser;
        public CSVApiController()
        {
            _csvParser = new CSVParser();
        }

        [HttpPost]
        [ResponseType(typeof(VehicleSalesResponse))]
        public IHttpActionResult VehicleSalesData([FromBody] string SelectedFileName)
        {
            return Ok(_csvParser.GetVehicleSalesByTextFieldParser(SelectedFileName));
        }

    }
}
