﻿using System;
using DealerTrack.DataContracts;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Description;
using DealerTrack.Parser;
using System.Net.Http;
using System.Net;

namespace DealerTrack.WebApi.Controllers
{
    public class HomeApiController : ApiController
    {
        private FileUpload _fileUpload;
        public HomeApiController()
        {
            _fileUpload = new FileUpload();
        }

        [HttpGet]
        [ResponseType(typeof(VehicleSales))]
        public IHttpActionResult AllUploadedFiles()
        {
            return Ok(_fileUpload.GetAllUploadedFiles());
        }

        [HttpPost]
        [ResponseType(typeof(FileUploadResponse))]
        public IHttpActionResult SaveFile(FileUploadRequest model)
        {
            if (ModelState.IsValid)
            {
                var result = _fileUpload.SaveFile(model);
                return Ok(result);
            }
            return BadRequest();
        }
    }
}
