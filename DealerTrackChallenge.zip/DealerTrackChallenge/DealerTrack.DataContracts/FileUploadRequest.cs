﻿using System.IO;

namespace DealerTrack.DataContracts
{
    public class FileUploadRequest
    {
        public string FileName { get; set; }

        public MemoryStream FileStream { get; set; }
    }
}
