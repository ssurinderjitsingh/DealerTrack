﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DealerTrack.DataContracts
{
    public class VehicleSales
    {
        [Display(Name = "Select File Name")]
        public string SelectedFileName { get; set; }

        [Required]
        public List<string> FileNames { get; set; } = new List<string>();

    }
}
