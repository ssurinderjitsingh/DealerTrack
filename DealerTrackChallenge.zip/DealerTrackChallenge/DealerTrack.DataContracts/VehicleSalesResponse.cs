﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DealerTrack.DataContracts
{
    public class VehicleSalesResponse
    {
        public List<VehicleSalesData> VehicleSalesResults { get; set; } = new List<VehicleSalesData>();

        public string MostSellingVehicle { get; set; }

        public decimal? TotalSalePrice { get; set; } = 0.0M;

        public string TotalSalesPriceFormatted
        {
            get
            {
                return TotalSalePrice == null ? string.Empty : string.Format("{0:C}", TotalSalePrice);
            }
        }

        public int TotalVehicleSold { get; set; }
    }
}
