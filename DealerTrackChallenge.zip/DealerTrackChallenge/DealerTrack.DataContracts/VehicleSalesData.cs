﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DealerTrack.DataContracts
{
    public class VehicleSalesData
    {
        public int  DealNumber { get; set; }

        public string CustomerName { get; set; }

        public string DealershipName { get; set; }

        public string Vehicle { get; set; }

        public decimal? Price { get; set; } = 0.0M;

        public string FormattedPrice
        {
            get
            {
                return Price == null ? string.Empty : string.Format("{0:C}", Price);
            }
        }

        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime? Date { get; set; }

        public string FormattedDate
        {
            get { return Date == null ? string.Empty : Date.Value.ToString("MM-dd-yyyy"); }
        }
    }
}
