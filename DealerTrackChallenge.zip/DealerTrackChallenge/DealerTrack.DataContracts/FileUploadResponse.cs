﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DealerTrack.DataContracts
{
    public class FileUploadResponse
    {
        public bool IsFileUploadSuccess { get; set; }

        public string FileName { get; set; }
    }
}
