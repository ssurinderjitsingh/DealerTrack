﻿using DealerTrack.DataContracts;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Mvc;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using System.Configuration;
using System.Net.Http.Formatting;

namespace DealerTrackChallenge.Controllers
{
    [AllowAnonymous]
    public class HomeController : Controller
    {
        #region Action Methods
        [HttpGet]
        public ActionResult Index()
        {
            var model = new VehicleSales();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(ConfigurationManager.AppSettings["APIURI"].ToString());
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = client.GetAsync("api/HomeApi/AllUploadedFiles").Result;
                if (response.IsSuccessStatusCode)
                {
                    return View(response.Content.ReadAsAsync(typeof(VehicleSales)).Result);
                }
            }
            return View(new VehicleSales());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Upload(HttpPostedFileBase upload)
        {
            if (ModelState.IsValid)
            {
                if (upload != null && upload.ContentLength > 0)
                {
                    if (upload.FileName.EndsWith(".csv"))
                    {
                        var fileuploadRequest = new FileUploadRequest();
                        CopyUploadedFileToMemoryStream(fileuploadRequest, upload);
                        using (var client = new HttpClient())
                        {
                            client.BaseAddress = new Uri(ConfigurationManager.AppSettings["APIURI"].ToString());
                            client.DefaultRequestHeaders.Accept.Clear();
                            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                            var result = client.PostAsync("api/HomeApi/SaveFile", fileuploadRequest, new JsonMediaTypeFormatter()).Result.Content.ReadAsAsync<FileUploadResponse>().Result;
                            if (result != null)
                            {
                                TempData["StatusMessage"] = "File Upload Succcessfully";
                                return RedirectToAction("Index");
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("File", "This file format is not supported");
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("File", "Please Upload Your file");
                }
            }
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult GetVehicleSales(string SelectedFileName)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ConfigurationManager.AppSettings["APIURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    var response = client.PostAsJsonAsync("api/CSVApi/VehicleSalesData/", SelectedFileName);
                    if(response.Result != null)
                    {
                        var model = response.Result.Content.ReadAsAsync<VehicleSalesResponse>().Result;
                        return PartialView("_vehicleSales", model);
                    }
                }
            }
            return PartialView("_vehicle", new VehicleSalesResponse());
        }

        #endregion

        #region Helper

        private void CopyUploadedFileToMemoryStream(FileUploadRequest fileUploadRequest, HttpPostedFileBase file)
        {
            byte[] fileBytes = new byte[file.ContentLength];
            file.InputStream.Read(fileBytes, 0, fileBytes.Length);

            fileUploadRequest.FileName = file.FileName;
            fileUploadRequest.FileStream = new MemoryStream(fileBytes);
        }
        #endregion


    }
}