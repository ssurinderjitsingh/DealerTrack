﻿using System.Web;
using System.Web.Optimization;

namespace DealerTrackChallenge
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*",
                        "~/Scripts/jquery.unobtrusive-ajax",
                        "~/Scripts/jquery.jquery.validate.unobtrusive"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                    "~/Content/bootstrap.css",
                    "~/Content/font-face.css"));

            bundles.Add(new StyleBundle("~/Content/fontcss").Include(
                   "~/Content/font-face.css"));
            bundles.Add(new StyleBundle("~/Content/mdi-font").Include(
                    "~/Content/material-design-iconic-font.css"));
         
            bundles.Add(new StyleBundle("~/Content/bootstrap-progressbarcss").Include(
                       "~/Content/bootstrap-progressbar-3.3.4.min.css"));
            bundles.Add(new StyleBundle("~/Content/select2css").Include(
                     "~/Content/select2.min.css"));
            bundles.Add(new StyleBundle("~/Content/hamburgers").Include(
                    "~/Content/hamburgers.min.css"));
            bundles.Add(new StyleBundle("~/Content/slick").Include(
                   "~/Content/slick.css"));
            bundles.Add(new StyleBundle("~/Content/perfect-scrollbarcss").Include(
                  "~/Content/perfect-scrollbar.css"));

            bundles.Add(new ScriptBundle("~/bundles/slick").Include(
                  "~/Scripts/slick.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/wow").Include(
            "~/Scripts/wow.min.js"));
            bundles.Add(new ScriptBundle("~/bundles/bootstrap-progressbar").Include(
           "~/Scripts/bootstrap-progressbar.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/counter-up").Include(
           "~/Scripts/jquery.waypoints.min.js",
           "~/Scripts/jquery.counterup.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/circle-progress").Include(
           "~/Scripts/circle-progress.min.js"));
            bundles.Add(new ScriptBundle("~/bundles/perfect-scrollbar").Include(
         "~/Scripts/perfect-scrollbar.js"));
            bundles.Add(new ScriptBundle("~/bundles/chartjs").Include(
       "~/Scripts/Chart.bundle.min.js"));
            bundles.Add(new ScriptBundle("~/bundles/select2").Include(
     "~/Scripts/select2.min.js"));
        }
    }
}
