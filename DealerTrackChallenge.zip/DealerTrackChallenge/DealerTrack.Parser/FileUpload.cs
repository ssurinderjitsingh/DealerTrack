﻿using System;
using System.IO;
using System.Collections.Generic;
using DealerTrack.DataContracts;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;
using System.Text;
using System.Globalization;
using System.Configuration;

namespace DealerTrack.Parser
{
    public class FileUpload
    {
        public VehicleSales GetAllUploadedFiles()
        {
            var directory = ConfigurationManager.AppSettings["FilePath"].ToString();
            CreateDirectory(directory);
            return new VehicleSales { FileNames = new DirectoryInfo(directory).GetFiles("*.csv").Select(o => o.Name).ToList() };
        }

        public FileUploadResponse SaveFile(FileUploadRequest model)
        {
            var response = new FileUploadResponse();
            try
            {
                string filePath = GetFilePath(model.FileName);
                response = SaveImage(filePath, model);
            }
            catch (Exception ex)
            {
                //LogError(ex);
                throw ex;
            }
            return response;
        }

        private string GetFilePath(string fileName)
        {
            var directory = ConfigurationManager.AppSettings["FilePath"].ToString();
            CreateDirectory(directory);
            return Path.Combine(directory, fileName);
        }

        private FileUploadResponse SaveImage(string filePath, FileUploadRequest fileUploadRequest)
        {
            try
            {
                byte[] imageBytes = ReadImageBytes(fileUploadRequest);
                if (imageBytes != null)
                {
                    if (!File.Exists(filePath))
                    {
                        {
                            using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
                            {
                                fileStream.Write(imageBytes, 0, imageBytes.Length);
                                return new FileUploadResponse { IsFileUploadSuccess = true, FileName = fileUploadRequest.FileName };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LogError(ex);
                return new FileUploadResponse { IsFileUploadSuccess = false, FileName = fileUploadRequest.FileName };
            }
            return new FileUploadResponse { IsFileUploadSuccess = false, FileName = fileUploadRequest.FileName };
        }

        private byte[] ReadImageBytes(FileUploadRequest fileUpoadRequest)
        {
            byte[] imageBytes = null;
            if (fileUpoadRequest.FileStream != null && fileUpoadRequest.FileStream.Length > 0)
            {
                imageBytes = new byte[fileUpoadRequest.FileStream.Length];
                fileUpoadRequest.FileStream.Read(imageBytes, 0, imageBytes.Length);
            }
            return imageBytes;
        }

        private void CreateDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }


    }
}
