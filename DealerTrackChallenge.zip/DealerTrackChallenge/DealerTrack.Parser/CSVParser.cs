﻿using System;
using System.IO;
using System.Collections.Generic;
using DealerTrack.DataContracts;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;
using System.Text;
using System.Globalization;
using System.Configuration;

namespace DealerTrack.Parser
{
    public class CSVParser
    {
        public List<VehicleSalesData> GetVehicleSalesDataByRegEx(string filePath)
        {
            if (File.Exists(filePath))
            {
                var vehicleSales = new VehicleSalesResponse();
                vehicleSales.VehicleSalesResults = File.ReadLines(filePath)
                    .Skip(1)
                    .Where(s => s != "")
                    .Select(s => Regex.Split(s, ",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))"))
                    .Select(a => new VehicleSalesData
                    {
                        DealNumber = int.Parse(a[0]),
                        CustomerName = a[1],
                        DealershipName = a[2],
                        Vehicle = a[3],
                        Price = decimal.Parse(a[4].Replace(",", "").Replace("\"", ""), System.Globalization.NumberStyles.Currency),
                        Date = DateTime.Parse(a[5]),
                    })
                    .ToList();

                var list = vehicleSales.VehicleSalesResults.GroupBy(v => v.Vehicle).OrderByDescending(gp => gp.Count()).Select(g => g.Key).ToList();
            }
            return null;
        }

        public VehicleSalesResponse GetVehicleSalesByTextFieldParser(string fileName)
        {
            var vehicleSales = new VehicleSalesResponse();
            try
            {
                var filePath = Path.Combine(ConfigurationManager.AppSettings["FilePath"].ToString(), fileName);
                using (TextFieldParser parser = new TextFieldParser(filePath, Encoding.GetEncoding("iso-8859-1")))
                {
                    parser.TextFieldType = FieldType.Delimited;
                    parser.HasFieldsEnclosedInQuotes = true;
                    parser.SetDelimiters(",");
                    parser.TrimWhiteSpace = true;
                    var firstLine = true;

                    while (!parser.EndOfData)
                    {
                        try
                        {
                            var fields = parser.ReadFields();
                            if (firstLine) { firstLine = false; continue; }
                            vehicleSales.VehicleSalesResults.Add(new VehicleSalesData
                            {
                                DealNumber = int.Parse(fields[0]),
                                CustomerName = fields[1],
                                DealershipName = fields[2],
                                Vehicle = fields[3],
                                Price = decimal.Parse(fields[4]),
                                Date = DateTime.Parse(fields[5]),
                            });
                        }
                        catch (MalformedLineException ex)
                        {
                            //logerror(ex)
                        }
                    }
                    vehicleSales.MostSellingVehicle = vehicleSales.VehicleSalesResults.GroupBy(v => v.Vehicle).OrderByDescending(gp => gp.Count()).Select(g => g.Key).First();
                    vehicleSales.TotalSalePrice = vehicleSales.VehicleSalesResults.Sum(v => v.Price);
                    vehicleSales.TotalVehicleSold = vehicleSales.VehicleSalesResults.Count();
                }
            }
            catch (FileNotFoundException ex)
            {
                //logerror(ex)
                throw;
            }
            catch (Exception ex)
            {
                //logerror(ex)
                throw;
            }

            return vehicleSales;
        }

        public List<string> loadCsvFile(string filePath)
        {
            var reader = new StreamReader(File.OpenRead(filePath), Encoding.GetEncoding("iso-8859-1"));
            List<string> searchList = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                searchList.Add(line);
            }
            return searchList;
        }
    }
}
